const PRICE_KOBO = 150000;
const APPS = {
  "taribeats-security-ventures": "TARIBEATS SECURITY VENTURES",
  "caleb-time-calculator": "Caleb Time Calculator",
  "caleb-diesel-calculator": "Caleb Diesel Calculator",
  "caleb-online-media-vault": "Caleb Online Media Vault",
  "caleb-tech-people-finder": "Caleb's Tech People Information Finder",
  "people-information-manager": "People Information Manager",
  "phone-profile-finder": "Phone Profile Finder",
  "caleb-my-phone-tracker": "Caleb My Phone Tracker"
};

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed." });
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return res.status(503).json({ error: "Paystack is not configured. Please contact the portfolio owner." });

  const { app_id: appId, email } = req.body || {};
  if (!Object.prototype.hasOwnProperty.call(APPS, appId)) {
    return res.status(400).json({ error: "Please choose a valid app." });
  }
  if (typeof email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    return res.status(400).json({ error: "Enter a valid email address." });
  }

  const forwardedHost = req.headers["x-forwarded-host"] || req.headers.host;
  const host = Array.isArray(forwardedHost) ? forwardedHost[0] : forwardedHost;
  if (!host || !/^[a-z0-9.-]+(?::\d+)?$/i.test(host)) {
    return res.status(400).json({ error: "Could not determine the portfolio address. Please refresh and try again." });
  }
  const local = host.startsWith("localhost") || host.startsWith("127.0.0.1");
  const callbackUrl = `${local ? "http" : "https"}://${host}/`;

  try {
    const response = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        email: email.trim(),
        amount: PRICE_KOBO,
        currency: "NGN",
        callback_url: callbackUrl,
        metadata: { app_id: appId, app_name: APPS[appId] }
      })
    });
    const payload = await response.json();
    if (!response.ok || !payload.status || !payload.data?.authorization_url) {
      return res.status(502).json({ error: payload.message || "Paystack could not initialize this payment." });
    }
    return res.status(200).json({
      authorization_url: payload.data.authorization_url,
      reference: payload.data.reference
    });
  } catch {
    return res.status(502).json({ error: "Unable to connect to Paystack. Please try again." });
  }
}
