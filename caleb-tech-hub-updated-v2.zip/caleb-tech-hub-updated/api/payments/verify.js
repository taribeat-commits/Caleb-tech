const PRICE_KOBO = 150000;
const APPS = {
  "taribeats-security-ventures": { name: "TARIBEATS SECURITY VENTURES", url: "https://taribeats-security-ventures-dupl20.v2.appdeploy.ai/" },
  "caleb-time-calculator": { name: "Caleb Time Calculator", url: "https://caleb-time-calculator-99vui2.v2.appdeploy.ai/" },
  "caleb-diesel-calculator": { name: "Caleb Diesel Calculator", url: "https://caleb-diesel-calculator-7tvpmi.v2.appdeploy.ai/" },
  "caleb-online-media-vault": { name: "Caleb Online Media Vault", url: "https://caleb-online-media-vault-ryccap.v2.appdeploy.ai/" },
  "caleb-tech-people-finder": { name: "Caleb's Tech People Information Finder", url: "https://caleb-s-tech-people-information-finder-y9u0cz.v2.appdeploy.ai/" },
  "people-information-manager": { name: "People Information Manager", url: "https://people-information-manager-33mydh.v2.appdeploy.ai/" },
  "phone-profile-finder": { name: "Phone Profile Finder", url: "https://phone-profile-finder-iw7vm8.v2.appdeploy.ai/" },
  "caleb-my-phone-tracker": { name: "Caleb My Phone Tracker", url: "https://caleb-my-phone-tracker-8ce8l2.v2.appdeploy.ai/" }
};

export default async function handler(req, res) {
  if (req.method !== "GET") return res.status(405).json({ error: "Method not allowed." });
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return res.status(503).json({ error: "Payment verification is temporarily unavailable." });
  const reference = typeof req.query.reference === "string" ? req.query.reference : "";
  if (!reference || reference.length > 120 || !/^[A-Za-z0-9._-]+$/.test(reference)) {
    return res.status(400).json({ error: "A valid payment reference is required." });
  }

  try {
    const response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: { Authorization: `Bearer ${secret}` }
    });
    const payload = await response.json();
    const transaction = payload.data;
    const appId = transaction?.metadata?.app_id;
    const selectedApp = APPS[appId];
    const verified = Boolean(
      response.ok && payload.status && transaction?.status === "success" &&
      transaction.amount === PRICE_KOBO && transaction.currency === "NGN" &&
      transaction.reference === reference && selectedApp
    );
    if (!verified) {
      return res.status(200).json({
        verified: false,
        message: "Payment has not been confirmed for this app. If you were charged, please contact support."
      });
    }
    return res.status(200).json({
      verified: true,
      app: { id: appId, name: selectedApp.name, url: selectedApp.url }
    });
  } catch {
    return res.status(502).json({ error: "Could not verify the payment with Paystack. Please try again." });
  }
}
