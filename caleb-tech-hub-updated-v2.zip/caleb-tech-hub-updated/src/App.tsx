import { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight, CheckCircle2, Clock3, Code2, Contact, ExternalLink,
  Fuel, Images, LockKeyhole, Mail, Search, ShieldCheck, Smartphone,
  Sparkles, WalletCards, ClipboardList
} from 'lucide-react';

type AppItem = {
  id: string; name: string; description: string; category: string;
  accent: string; url: string; icon: typeof Code2;
};

const apps: AppItem[] = [
  { id:'taribeats-security-ventures', name:'TARIBEATS SECURITY VENTURES',
    description:'A private company information workspace for reports, guards, clients, supervisors, and investigation records.',
    category:'Business & Security', accent:'rose', url:'https://taribeats-security-ventures-dupl20.v2.appdeploy.ai/', icon:ShieldCheck },
  { id:'caleb-time-calculator', name:'Caleb Time Calculator',
    description:'Add, subtract, and compare times with a simple, practical calculator.',
    category:'Productivity', accent:'blue', url:'https://caleb-time-calculator-99vui2.v2.appdeploy.ai/', icon:Clock3 },
  { id:'caleb-diesel-calculator', name:'Caleb Diesel Calculator',
    description:'Estimate generator diesel consumption and calculate fuel requirements across generator sizes.',
    category:'Business Utility', accent:'amber', url:'https://caleb-diesel-calculator-7tvpmi.v2.appdeploy.ai/', icon:Fuel },
  { id:'caleb-online-media-vault', name:'Caleb Online Media Vault',
    description:'A private online space for organizing pictures, videos, MP3 songs, and audio files.',
    category:'Storage', accent:'violet', url:'https://caleb-online-media-vault-ryccap.v2.appdeploy.ai/', icon:Images },
  { id:'caleb-tech-people-finder', name:"Caleb's Tech People Information Finder",
    description:'Create, search, edit, and manage saved people profiles with photo and video records.',
    category:'Information Management', accent:'cyan', url:'https://caleb-s-tech-people-information-finder-y9u0cz.v2.appdeploy.ai/', icon:Contact },
  { id:'people-information-manager', name:'People Information Manager',
    description:'A private workspace for writing, editing, searching, and retrieving personal information records.',
    category:'Information Management', accent:'green', url:'https://people-information-manager-33mydh.v2.appdeploy.ai/', icon:ClipboardList },
  { id:'phone-profile-finder', name:'Phone Profile Finder',
    description:'A consent-based directory where people choose whether their own profile can be found by phone number.',
    category:'Directory', accent:'indigo', url:'https://phone-profile-finder-iw7vm8.v2.appdeploy.ai/', icon:Search },
  { id:'caleb-my-phone-tracker', name:'Caleb My Phone Tracker',
    description:'A personal device-location tool with consent-based phone-number information checking.',
    category:'Personal Utility', accent:'slate', url:'https://caleb-my-phone-tracker-8ce8l2.v2.appdeploy.ai/', icon:Smartphone }
];

type Unlock = { id: string; name: string; url: string };

export default function App() {
  const [emails, setEmails] = useState<Record<string,string>>({});
  const [loadingId, setLoadingId] = useState('');
  const [notice, setNotice] = useState('');
  const [unlocked, setUnlocked] = useState<Unlock | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All apps');

  const categories = ['All apps', ...Array.from(new Set(apps.map(a => a.category)))];
  const filteredApps = useMemo(() => apps.filter(a =>
    (a.name + ' ' + a.description).toLowerCase().includes(search.toLowerCase()) &&
    (category === 'All apps' || a.category === category)
  ), [search, category]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const reference = params.get('reference') || params.get('trxref');
    if (!reference) return;
    let active = true;
    setVerifying(true);
    fetch(`/api/payments/verify?reference=${encodeURIComponent(reference)}`)
      .then(async r => {
        const data = await r.json();
        if (!r.ok) throw new Error(data.error || 'Payment verification failed.');
        return data;
      })
      .then(result => {
        if (!active) return;
        if (result.verified && result.app?.url) {
          setUnlocked(result.app);
          setNotice('Payment confirmed. Your app access is ready below.');
        } else {
          setNotice(result.message || 'We could not confirm this payment. Please contact support before trying again.');
        }
      })
      .catch(err => { if (active) setNotice(err.message || 'Payment verification could not be completed.'); })
      .finally(() => {
        if (active) setVerifying(false);
        const clean = new URL(window.location.href);
        clean.searchParams.delete('reference');
        clean.searchParams.delete('trxref');
        window.history.replaceState({}, '', clean.toString());
      });
    return () => { active = false; };
  }, []);

  async function buyApp(item: AppItem) {
    const email = (emails[item.id] || '').trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setNotice('Please enter a valid email address for your Paystack receipt.');
      return;
    }
    setNotice('');
    setUnlocked(null);
    setLoadingId(item.id);
    try {
      const response = await fetch('/api/payments/initialize', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({app_id:item.id,email})
      });
      const result = await response.json();
      if (!response.ok || !result.authorization_url) {
        throw new Error(result.error || 'Paystack could not start checkout.');
      }
      window.location.assign(result.authorization_url);
    } catch (err) {
      setNotice(err instanceof Error ? err.message : 'Checkout could not be started. Please try again.');
      setLoadingId('');
    }
  }

  return <div className="site-shell">
    <header className="topbar">
      <a className="brand" href="#top"><img src="/resources/caleb-apps-logo.svg" alt="" /><span>CALEB<span className="brand-light">APPS</span></span></a>
      <nav><a href="#apps">Apps</a><a href="#services">Services</a><a href="#how-it-works">How it works</a><a href="#contact">Contact</a></nav>
      <a className="top-cta" href="#apps">Explore apps <ArrowRight size={16}/></a>
    </header>
    <main id="top">
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><Sparkles size={14}/> DIGITAL TOOLS BY CALEB</div>
          <h1>Useful apps.<br/><span>One simple place.</span></h1>
          <p>Explore practical digital tools built to make everyday work easier. Choose an app, pay securely, and unlock access in minutes.</p>
          <div className="hero-actions"><a className="primary-button" href="#apps">Browse the apps <ArrowRight size={17}/></a><a className="text-button" href="#how-it-works">How access works</a></div>
          <div className="hero-proof"><span><ShieldCheck size={16}/> Secure Paystack checkout</span><span><LockKeyhole size={15}/> Access after payment</span></div>
        </div>
        <div className="hero-art"><div className="orbit one"/><div className="orbit two"/>
          <div className="hero-tile"><div className="tile-icon"><Code2 size={30}/></div><small>YOUR DIGITAL TOOLKIT</small><strong>Build. Work.<br/>Get more done.</strong><div className="tile-bottom"><span>CALEB APPS</span><span>01 — 08</span></div></div>
          <div className="float-card float-one"><WalletCards size={18}/> Easy payment</div><div className="float-card float-two"><CheckCircle2 size={18}/> Verified access</div>
        </div>
      </section>
      <section className="trust-strip"><div><strong>08</strong><span>Available apps</span></div><div><strong>₦1,500</strong><span>Simple price per app</span></div><div><strong>Paystack</strong><span>Secure payment checkout</span></div></section>
      <section className="services-section" id="services">
        <div className="services-heading">
          <div className="eyebrow">OUR JOBS AND SERVICES</div>
          <h2>Artificial Intelligence Services</h2>
          <p>Practical AI assistance and learning opportunities developed by Caleb's Tech Hub.</p>
        </div>
        <article className="assistant-service">
          <div className="assistant-logo-wrap"><img src="/resources/caleb-assistant-desk.png" alt="Caleb Assistant Desk logo" /></div>
          <div className="assistant-copy">
            <div className="service-kicker">A CALEB'S TECH HUB PRODUCT</div>
            <h3>Caleb Assistant Desk</h3>
            <p>Caleb Assistant Desk is an artificial intelligence assistant — a robot built by Caleb's Tech Hub to help settle, manage and handle issues for humans through intelligent assistance.</p>
            <h4>Why Caleb Assistant Desk is different</h4>
            <p>Users can track their messages and monitor questions even when an answer has not yet been received, helping them follow the progress of their requests.</p>
            <h4>AI assistance when you need it</h4>
            <p>Ask Caleb Assistant Desk AI questions, request help and receive instant solutions whenever the service is available.</p>
          </div>
          <div className="training-panel">
            <h4>Training programmes</h4>
            <p>Apply for brief educational and skills-based training programmes. A diploma or certificate may be issued by Caleb's Tech Hub upon successful completion, in line with the programme requirements.</p>
            <ul>
              <li>Security trainings</li><li>Cyber technology trainings</li><li>Artificial intelligence trainings</li>
              <li>Web development trainings</li><li>Investigation trainings</li><li>Biblical and religious studies</li>
              <li>Human source intelligence trainings</li><li>Legal practice trainings</li><li>Content creator trainings</li><li>And many more</li>
            </ul>
            <p className="training-note">Just ask us and apply. Once your application is reviewed and accepted, your training can begin.</p>
            <a className="primary-button" href="mailto:tamunotaricaleb@gmail.com?subject=Caleb%20Assistant%20Desk%20Training%20Application">Ask about training <ArrowRight size={16}/></a>
          </div>
        </article>
      </section>
      <section className="apps-section" id="apps">
        <div className="section-heading"><div><div className="eyebrow">THE COLLECTION</div><h2>Find your next useful tool.</h2><p>Every app is individually priced. Pay once to unlock access to the app you choose.</p></div><span className="app-count">{filteredApps.length} apps shown</span></div>
        <div className="filters"><label className="search-box"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search apps..."/></label>
          <div className="category-list">{categories.map(c=><button key={c} className={category===c?'category active':'category'} onClick={()=>setCategory(c)}>{c}</button>)}</div>
        </div>
        {notice && <div className={unlocked?'notice success':'notice'} role="status">{unlocked?<CheckCircle2 size={19}/>:<ShieldCheck size={19}/>}<span>{verifying?'Verifying your Paystack payment securely…':notice}</span></div>}
        {unlocked && <div className="unlock-panel"><CheckCircle2 size={28}/><div><small>PAYMENT CONFIRMED</small><h3>{unlocked.name} is ready.</h3><p>Your payment has been verified. Use the button to open your app.</p></div><a className="primary-button" href={unlocked.url} target="_blank" rel="noreferrer">Open my app <ExternalLink size={16}/></a></div>}
        <div className="app-grid">{filteredApps.map((item,i)=>{const Icon=item.icon;return <article className="app-card" key={item.id}>
          <div className="card-topline"><div className={'app-icon '+item.accent}><Icon size={24}/></div><span>{String(i+1).padStart(2,'0')}</span></div>
          <div className="app-category">{item.category}</div><h3>{item.name}</h3><p className="app-description">{item.description}</p><div className="card-divider"/>
          <div className="price-row"><div><small>ONE-TIME ACCESS</small><strong>₦1,500</strong></div><span><LockKeyhole size={13}/> Paid access</span></div>
          <label className="email-field"><Mail size={15}/><input type="email" value={emails[item.id]||''} onChange={e=>setEmails(old=>({...old,[item.id]:e.target.value}))} placeholder="Email for payment receipt" aria-label={'Email for '+item.name}/></label>
          <button className="buy-button" onClick={()=>buyApp(item)} disabled={Boolean(loadingId)}>{loadingId===item.id?'Connecting to Paystack…':'Pay ₦1,500 & unlock'}{loadingId===item.id?null:<ArrowRight size={16}/>}</button>
        </article>})}</div>
        {filteredApps.length===0 && <div className="empty-state">No apps match that search. Try another name or category.</div>}
      </section>
      <section className="steps-section" id="how-it-works"><div className="eyebrow">SIMPLE & SECURE</div><h2>Three steps to get started.</h2><div className="steps-grid">
        <article><b>01</b><h3>Choose an app</h3><p>Browse the collection and select the tool you want to use.</p></article>
        <article><b>02</b><h3>Pay securely</h3><p>Complete the ₦1,500 payment through Paystack using your preferred payment method.</p></article>
        <article><b>03</b><h3>Unlock access</h3><p>After the server confirms payment, your personal access link appears on this page.</p></article>
      </div></section>
      <section className="contact-section" id="contact"><div><div className="eyebrow">NEED HELP?</div><h2>We're here to help.</h2><p>For app access or payment questions, contact the portfolio owner.</p></div><a className="contact-link" href="mailto:tamunotaricaleb@gmail.com"><Mail size={17}/> tamunotaricaleb@gmail.com <ArrowRight size={16}/></a></section>
    </main>
    <footer><a className="brand" href="#top"><img src="/resources/caleb-apps-logo.svg" alt=""/>CALEB<span className="brand-light">APPS</span></a><span>© {new Date().getFullYear()} Caleb Apps. All rights reserved.</span><span>Payments processed securely by Paystack.</span></footer>
  </div>;
}
