# Caleb's Tech Hub — Vercel-ready

This is the Vercel adaptation of the Caleb's Tech Hub portfolio.

## Included
- The same eight app listings and ₦1,500 one-time price per app.
- Responsive portfolio frontend (React + Vite).
- Vercel serverless API routes for Paystack initialization and verification.
- Paystack secret is read only from `PAYSTACK_SECRET_KEY`; it is not stored in frontend code.
- A portfolio logo/favicon asset.

## Deploy
1. Create a private GitHub repository and upload the contents of this folder.
2. In Vercel, choose **Add New → Project**, import that GitHub repository, and deploy.
3. In Vercel Project Settings → Environment Variables, add `PAYSTACK_SECRET_KEY`.
4. Paste your Paystack secret key directly into Vercel's secure Environment Variables form. Never put it in a source file or commit it to GitHub.
5. Redeploy after adding the environment variable.
6. Test checkout using Paystack test credentials first. Switch to live credentials only after the full test succeeds.

## Local development
- `npm install`
- Set `PAYSTACK_SECRET_KEY` in a local `.env` file (do not commit it).
- `npm run dev`

## Important migration notes
- The portfolio site and its Paystack API are prepared for Vercel.
- The eight linked apps still point to their existing AppDeploy URLs. Moving the portfolio does not migrate those eight separate apps.
- Access is revealed after the server verifies a successful ₦1,500 NGN Paystack transaction. This is the same link-unlock model as the existing portfolio; it does not create per-customer accounts or revoke shared app URLs.
- Keep the existing AppDeploy portfolio online until the Vercel deployment and payment flow have been tested.


## Artificial Intelligence Services
- Caleb Assistant Desk service overview and supplied logo.
- Description of message tracking, AI assistance, and listed training programmes.
- Training enquiries use the portfolio contact email.
